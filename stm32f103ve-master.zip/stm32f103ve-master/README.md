# stm32f103vet6

KEIL uVision V5.25.2.0

STM32CubeMX V4.26.0

<img src=https://user-images.githubusercontent.com/27884304/43831735-11862c62-9b40-11e8-9483-e4ce49be028b.jpg />
