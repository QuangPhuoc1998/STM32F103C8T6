#ifndef __DHT22_H
#define __DHT22_H

#include "stm32f1xx_hal.h"
#include "main.h"

void read_dht_data(void);
	
#endif
